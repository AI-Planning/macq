"""
.. include:: ../docs/templates/index.md
"""
